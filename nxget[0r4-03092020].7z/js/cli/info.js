#!/usr/bin/env node
// info.js <> code
// modulo del comando nxget "info"
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const packageJson = require('../../package.json');
// <editor-fold>

// <editor-fold> funzione info -> restituisce le info su nxget
function info() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`versione: ${packageJson.version}`))
  console.log(chalk.hex('#aba9a9')(`build: ${packageJson.build}`))
  console.log("");
  console.log("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati.")
  console.log("");
  console.log(chalk.hex('#959595')("Descrizione:"));
  console.log("nxget è un package manager che consente di installare le applicazioni e altri pacchetti dalla riga di comando.");
  console.log("Si basa su manifesti, file in formato YAML che contengono le informazioni necessarie per l'installazione");
  console.log("dei software.");
  console.log("");
  console.log(chalk.hex('#959595')("Crediti"));
  console.log("Un ringraziamento speciale va a KEIVAN BEIGI, l'autore originale di AppGet, il software che ha ispirato l'idea di nxget.");
  console.log("per altre info: " + chalk.hex('#7fa2e7')("https://keivan.io/"));
  console.log("Un rigraziamento anche agli sviluppatori della community di npm, alcuni dei loro pacchetti hanno reso possibile nxget");
  console.log("per dettagli sui pacchetti che utilizza nxget digita il comando: " + chalk.hex('#fbffd2')("nxget npminfo"));
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  info
};
// </editor-fold>
