// nxget.js <> code
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const packageJson = require('../package.json');
const argv = require('yargs').argv;
const chalk = require('chalk');
var nxgetCommand = argv._[0]
// </editor-fold>

// <editor-fold> Comandi CLI - import moduli
const cli = {};
cli.commandlist = require('./cli/commandlist')
cli.info = require('./cli/info')
cli.npmpkg = require('./cli/npmpkg')
// </editor-fold>

// <editor-fold> nxget - output base
function nxgetOut() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`ver: ${packageJson.version} build: ${packageJson.build}`))
  console.log(chalk.hex('#aba9a9')("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati."))
  cli.commandlist()
}
// </editor-fold>

// <editor-fold> nxget Command Interpreter
switch (nxgetCommand) {
  case undefined:
    nxgetOut()
    break;
  case "info":
    cli.info()
    break;
  case "npmpkg":
    cli.npmpkg()
    break;
  default:
    console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " comando '" + chalk.hex('#9166d0')(`${nxgetCommand}`) + "' non riconosciuto.")
    console.log("");
    console.log(">> usa il comando " + chalk.hex('#98d066')(`'nxget'`) + " per visualizzare le informazioni di utilizzo di nxget");
}
// </editor-fold>
