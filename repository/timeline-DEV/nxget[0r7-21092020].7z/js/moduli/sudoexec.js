// sudoexec.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm "sudo-prompt"
// comando : npm install sudo-prompt
//
// Modulo che consente di eseguire comandi come Admin su diversi OS
// es. di utilizzo:
//         sudoexec(comando)
//         .then( async (output) => {console.log(output);})
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const sudo = require('sudo-prompt');
// </editor-fold>

// <editor-fold> Funzione del Modulo
async function sudoexec(comando) {
  return new Promise(async function(resolve) {
    var options = {
      name: "Admin",
    };
    sudo.exec(comando, options,
      function(error, stdout, stderr) {
        if (error) {
          console.log(" ");
          console.log("Permessi amministrativi NEGATI dall'utente.");
        } else {
          var output = stdout
          resolve(output)
        }
      }
    );
  });
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = sudoexec;
// </editor-fold
