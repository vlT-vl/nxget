// show.js <> code
// modulo del comando nxget "show"
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const chalk = require('chalk');
const fetch = require('node-fetch')
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const yamlparse = require('../moduli/yamlparse')
var manifest = argv._[1]
// </editor-fold>

// <editor-fold> Funzione del Modulo
function show() {
  if (manifest == undefined) {
    console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " show ")
    console.log("");
    console.log(">> Manca il parametro richiesto  '" + chalk.hex('#9166d0')(`<applicazione>`) + "' -> manifest dell'applicazione di cui mostrare i dettagli.");
  } else {
    yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
      .then(async (yamlData) => {
        var ricerca = searchEngine(yamlData, manifest)
        if (ricerca == "") {
          console.log(" ");
          console.log(chalk.hex('#b6b2b2')(`nxget || non esiste nessun pacchetto con nome: `) + chalk.hex('#f7ffc4')(manifest));
        } else {
          console.log(" ");
          console.log(chalk.hex('#b6b2b2')(`nxget || dettagli del pacchetto: `) + chalk.hex('#f7ffc4')(manifest));
          console.log("-------------------------------------------------");
          console.log(" ");
          ricerca.forEach(function(yaml) {
            manifest = yaml.manifest
          });
          const yamlfetch = await fetch(manifest)
          const yamlfile = await yamlfetch.text()
          console.log(yamlfile);
        }
      })
  }
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = show;
// </editor-fold>
