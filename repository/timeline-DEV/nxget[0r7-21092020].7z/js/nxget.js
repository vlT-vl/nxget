#!/usr/bin/env node
// nxget.js <> code
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const packageJson = require('../package.json');
const argv = require('yargs').argv;
const chalk = require('chalk');
const yamlparse = require('./moduli/yamlparse')
var nxgetCommand = argv._[0]
var securitytoken = "NXGET38JS2JK0923JKS903912IKS$"
// </editor-fold>

// <editor-fold> Comandi CLI - import moduli
const cli = {};
cli.commandlist = require('./cli/commandlist')
cli.info = require('./cli/info')
cli.npmpkg = require('./cli/npmpkg')
cli.hash = require('./cli/hash')
cli.show = require('./cli/show')
cli.search = require('./cli/search')
cli.install = require('./cli/install')
// </editor-fold>

// <editor-fold> nxget - output base
function nxgetOut() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`ver: ${packageJson.version} build: ${packageJson.build}`))
  console.log(chalk.hex('#aba9a9')("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati."))
  cli.commandlist()
}
// </editor-fold>

// <editor-fold> nxget Command Interpreter
yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/repository/nxget.yaml")
  .then(async (yamlData) => {
    if (yamlData.securitytoken == securitytoken) {
      switch (nxgetCommand) {
        case undefined:
          nxgetOut()
          break;
        case "info":
          cli.info()
          break;
        case "npmpkg":
          cli.npmpkg()
          break;
        case "hash":
          cli.hash()
          break;
        case "show":
          cli.show()
          break;
        case "search":
          cli.search()
          break;
        case "install":
          cli.install()
          break;
        default:
          console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " comando '" + chalk.hex('#9166d0')(`${nxgetCommand}`) + "' non riconosciuto.")
          console.log("");
          console.log(">> usa il comando " + chalk.hex('#98d066')(`'nxget'`) + " per visualizzare le informazioni di utilizzo di nxget");
      }
    } else {
      console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " computer non abilitato ad eseguire nxget: " + chalk.hex('#9166d0')(`securitytoken`) + " non abilitato.")
      console.log("");
      console.log(">> per maggiori dettagli contattata l'amministratore di nxget all'indirizzo email: " + chalk.hex('#a4a7fc')("veronesilorenzo@outlook.com"));
    }
  })
// </editor-fold>
