// powershellcore.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm node-powershell
// comando : npm install node-powershell
//
// Modulo che consente di lanciare comandi powershell da nodejs
// es. di utilizzo:
//         powershell(`$env:COMPUTERNAME`)
//         .then( async ()=> {console.log('comando powershell eseguito')})
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const shell = require('node-powershell');
// </editor-fold>

// <editor-fold> Funzione del Modulo
function powershell(comando) {
  return new Promise((resolve) => {
      const ps = new shell({
        executionPolicy: 'Bypass',
        noProfile: true
      });
      ps.addCommand(comando);
      ps.invoke()
        .then(output => {
          //console.log(output);
          ps.dispose()
          resolve();
        })
        .catch(err => {
          console.log(err);
        });
    });
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = powershell;
// </editor-fold
