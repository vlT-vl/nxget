// search.js <> code
// modulo del comando nxget "search"
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const chalk = require('chalk');
const cliTable = require('cli-table');
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const yamlparse = require('../moduli/yamlparse')
let parametroRicerca = argv._[1]
let pkgTable;
// </editor-fold>

// <editor-fold> Funzione del Modulo
function search() {
  if (parametroRicerca == undefined) {
    console.log(" ");
    console.log(chalk.hex('#b6b2b2')(`nxget || lista completa dei pacchetti disponibili`));
    console.log("-------------------------------------------------");
    yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
      .then(async (yamlData) => {
        pkgTab(yamlData)
      });
  } else {
    yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
      .then(async (yamlData) => {
        let ricerca = searchEngine(yamlData, parametroRicerca)
        if (ricerca == "") {
          console.log(" ");
          console.log(chalk.hex('#b6b2b2')(`nxget || nessun risultato della ricerca per: `) + chalk.hex('#f7ffc4')(parametroRicerca));
        } else {
          console.log(" ");
          console.log(chalk.hex('#b6b2b2')(`nxget || risultato della ricerca per: `) + chalk.hex('#f7ffc4')(parametroRicerca));
          console.log("-------------------------------------------------");
          pkgTab(ricerca)
        }
      });
  }
}
// </editor-fold>

// <editor-fold> Costruttore Tabella pkgTable
function pkgTab(data) {
  pkgTable = new cliTable({
    head: [chalk.hex('#959595')('Software'), chalk.hex('#959595')('id'), chalk.hex('#959595')('idx'), chalk.hex('#959595')('versione'), chalk.hex('#959595')('repository')],
  });
  data.forEach(function(yaml) {
    pkgTable.push([yaml.nome, yaml.id, yaml.idx, yaml.versione, yaml.repository], )
  });
  pkgTable = pkgTable.toString()
  console.log(pkgTable)
};
// </editor-fold>


// <editor-fold> export del modulo
module.exports = search;
// </editor-fold>
