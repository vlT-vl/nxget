// install.js <> code
// modulo del comando nxget "install"
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const chalk = require('chalk');
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const fs = require('fs')
const yamlparse = require('../moduli/yamlparse')
const hashfile = require('../moduli/hashfile')
const downloadfile = require('../moduli/downloadfile')
const sudoexec = require('../moduli/sudoexec')
const powershell = require('../moduli/powershellcore')
let manifest = argv._[1];
let adminflag = argv._[2];
// </editor-fold>

// <editor-fold> Funzione del Modulo
function install() {
  if (manifest == undefined) {
    console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " install ")
    console.log("");
    console.log(">> Manca il parametro richiesto '" + chalk.hex('#9166d0')(`<applicazione>`) + "' -> manifest dell'applicazione da installare.");
    console.log("");
    console.log(">> per una lista completa dei pacchetti disponibili digita: " + chalk.hex('#fbffd2')("'nxget search'"));
  } else {
    // -> Ricerca dell'applicazione nel DB e load del Manifest
    yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
      .then(async (yamlData) => {
        let ricerca = searchEngine(yamlData, manifest)
        let manifestApp;
        if (ricerca == "") {
          console.log(" ");
          console.log(chalk.hex('#b6b2b2')(`nxget || non esiste nessun pacchetto con nome: `) + chalk.hex('#f7ffc4')(manifest));
        } else {
          ricerca.forEach(function(yaml) {
            manifestApp = yaml.manifest
          });
          manifestApp = await yamlparse(manifestApp)
          // -> Check ID pacchetto
          switch (manifest) {
            case manifestApp.id:
              deploy(manifestApp)
              break;
            case manifestApp.idx:
              deploy(manifestApp)
              break;
            default:
              console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " install ")
              console.log("");
              console.log(">> il parametro richiesto '" + chalk.hex('#9166d0')(`${manifest}`) + "' -> non corrisponde all'ID o all'IDX dell'applicazione");
          }
        }
      });
  }
}
// </editor-fold>

// <editor-fold>  Funzione deploy
//  -> Funzione per il deploy del pacchetto
async function deploy(manifest) {

  //  -> Impostazioni delle variabili del deploy
  let package = `${manifest.id}-${manifest.versione}.${manifest.installer.installertype}`
  let nxgetFLDR = `${process.env.TEMP}\\nxget`
  let exePath = `${nxgetFLDR}\\${package}`

  //  -> ConsoleLOG base del comando "install"
  console.log(" ");
  console.log(`Pacchetto: ` + chalk.hex('#f7ffc4')(manifest.id));
  console.log("Versione: " + chalk.hex('#f7ffc4')(manifest.versione));
  console.log(" ");
  downloadPKG(manifest, nxgetFLDR, package)

  //  -> Download del file da URL
  // la cartela nxget in TEMP viene creata automaticamntedal modulo downloadfile
  async function downloadPKG(manifest, nxgetFLDR, package) {
    console.log(`Download di: ` + chalk.hex('#898dee')(manifest.installer.url));
    downloadfile(manifest.installer.url, nxgetFLDR, package)
      .then(() => {
        console.log(" ");
        console.log(`Download di: ` + chalk.hex('#f7ffc4')(manifest.id) + " >> COMPLETATO CORRETTAMENTE");
        checkmd5(manifest, exePath, nxgetFLDR)
      });
  }

  //  -> Check Hash MD5 file scaricato
  async function checkmd5(manifest, exePath, nxgetFLDR) {
    hashfile(exePath)
      .then(async (md5) => {
        if (md5 != manifest.installer.MD5) {
          console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " hash ")
          console.log("");
          console.log(">> il checksum MD5 del file non corrisponde con il checksum MD5 del manifest dell'applicazione");
          console.log(" ");
          console.log(chalk.hex('#f6963e')(`MD5: ${md5} - File Scaricato`))
          console.log(chalk.hex('#f6d93e')(`MD5: ${manifest.installer.MD5} - Manifest dell'applicazione`))
          console.log(" ");
          console.log(chalk.hex('#f63e3e')(`installazione del pacchetto nxget: ` + chalk.hex('#f7ffc4')(manifest.id) + ` interrotta.`))
          fs.rmdirSync(nxgetFLDR, {
            recursive: true
          });
        } else {
          installPKG(manifest, exePath, nxgetFLDR)
        }
      });
  }

  //  -> Installazione del pacchetto selezionato
  async function installPKG(manifest, exePath, nxgetFLDR) {
    console.log(" ");
    console.log(`Installazione del pacchetto nxget: ` + chalk.hex('#f7ffc4')(manifest.id) + ` in corso.....`)
    if ((manifest.installer.installertype == "msi") || (adminflag == ".admin")) {
      await sudoexec(`PowerShell -NoProfile -ExecutionPolicy Bypass -Command "$proc = Start-Process -Wait -FilePath '${exePath}' -ArgumentList '${manifest.installer.arguments}'; do{sleep 1}while(Get-Process -Name '${manifest.id}-${manifest.versione}' -ErrorAction SilentlyContinue)"`)
        .then(() => {
          console.log(" ");
          console.log(`Installazione di: ` + chalk.hex('#f7ffc4')(manifest.id) + " >> COMPLETATA CORRETTAMENTE");
          console.log(" ");
          setTimeout(function() {
            fs.rmdirSync(nxgetFLDR, {
              recursive: true
            });
          }, 500);
        });
    } else {
      powershell(`$proc = Start-Process -Wait -FilePath '${exePath}' -ArgumentList '${manifest.installer.arguments}'; do{sleep 1}while(Get-Process -Name '${manifest.id}-${manifest.versione}' -ErrorAction SilentlyContinue)`)
        .then(async () => {
          console.log(" ");
          console.log(`Installazione di: ` + chalk.hex('#f7ffc4')(manifest.id) + " >> COMPLETATA CORRETTAMENTE");
          console.log(" ");
          setTimeout(function() {
            fs.rmdirSync(nxgetFLDR, {
              recursive: true
            });
          }, 500);
        })
    }
  }
};

// <editor-fold> export del modulo
module.exports = install;
// </editor-fold>
