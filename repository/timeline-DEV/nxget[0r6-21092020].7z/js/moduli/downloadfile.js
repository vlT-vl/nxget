// downloadfile.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm "nodejs-file-downloader"
// comando : npm install nodejs-file-downloader
//
// Modulo che consente di effettuare il download di un file da js
// es. di utilizzo:
//         downloadfile(url, dest, fileName)
//         .then( async () => {console.log("Download Compleatato");})
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const downloader = require('nodejs-file-downloader');
// </editor-fold>

// <editor-fold> Funzione del Modulo
async function downloadfile(url, dest, fileName) {
  const downloadfile = new downloader({
    url: url,
    directory: dest,
    fileName: fileName,
    cloneFiles: false
  })
  var status = await downloadfile.download()
  return status
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = downloadfile;
// </editor-fold
