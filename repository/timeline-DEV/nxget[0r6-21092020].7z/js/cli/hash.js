// hash.js <> code
// modulo del comando nxget "hash"
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const chalk = require('chalk');
const fs = require('fs')
const argv = require('yargs').argv;
const hashfile = require('../moduli/hashfile')
const percorsofile = argv._[1]
// </editor-fold>

// <editor-fold> Funzione del Modulo
function hash() {
  if (percorsofile != undefined) {
    if (fs.existsSync(percorsofile)) {
      var fileName = percorsofile.split("\\");
      var index = fileName.length - 1
      hashfile(percorsofile)
        .then(async (md5) => {
          console.log(chalk.hex('#6ac26d')(`File: ${fileName[index]} - check md5`));
          console.log(chalk.hex('#c4fcc6')(`MD5: ${md5}`));
        })
    } else {
      console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " hash -> File:'" + chalk.hex('#9166d0')(`${percorsofile}`) + "' non esistente.")
    }
  } else {
    console.log(`nxget ` + chalk.hex('#cd1414')("ERROR") + " hash ")
    console.log("");
    console.log(">> Manca il parametro richiesto  '" + chalk.hex('#9166d0')(`<percorsofile>`) + "' -> percorso del file di cui verificare l'hash MD5");
  }
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = hash;
// </edit
