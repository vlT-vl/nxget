// yamlparse.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm "js-yaml" e "node-fetch"
// comando : npm install js-yaml node-fetch
//
// Modulo che consente il parse di un file yaml da url https
// es. di utilizzo:
//          yamlparse(filePath)
//         .then( async (yamlData) => { console.log(yamlData) })
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const fetch = require('node-fetch')
const yaml = require('js-yaml');
// </editor-fold>

// <editor-fold> Funzione del Modulo
async function yamlparse(filePath) {
  return new Promise(async function(resolve) {
    const yamlfetch = await fetch(filePath)
    const yamlfile = await yamlfetch.text()
    const yamlData = yaml.safeLoad(yamlfile);
    resolve(yamlData)
  });
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = yamlparse;
// </editor-fold
