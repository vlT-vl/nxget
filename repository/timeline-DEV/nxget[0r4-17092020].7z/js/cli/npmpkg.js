// npmpkg.js <> code
// modulo del comando nxget "npmpkg"
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const chalk = require('chalk');
const packageJson = require('../../package.json');
const cliTable = require('cli-table');
var npmPackages = packageJson.dependencies;
var npmTable;
// </editor-fold>

// <editor-fold> Funzione del Modulo
function npmpkg() {
  console.log(" ");
  console.log(chalk.whiteBright("nxget | pacchetti npm"))
  console.log(chalk.hex('#959595')("pacchetti npm implementati in nxget"));
  console.log("-----------------------------------");;
  npmTab()
}
// </editor-fold>

// <editor-fold> Costruttore Tabella npm
function npmTab() {
  npmTable = new cliTable({
    head: [chalk.hex('#959595')('pacchetto npm'), chalk.hex('#959595')('versione')],
  });
  var npm = Object.keys(npmPackages).map(function(key) {
    return [String(key), npmPackages[key], ];
  });
  npm.forEach(function(npm) {
    npmTable.push([npm[0], npm[1]])
  });
  npmTable = npmTable.toString()
  console.log(npmTable);
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = npmpkg;
// </edit
