// commandlist.js <> code
// modulo che restituisce la lista dei comandi nxget
//******************************************************************************

// <editor-fold> Costanti e Varibili del Modulo
const chalk = require('chalk');
// </editor-fold>

// <editor-fold> Funzione del Modulo
function commandlist() {
  console.log("");
  console.log("Utilizzo: nxget <comando> <parametro>");
  console.log("");
  console.log(chalk.hex('#959595')("Sono disponibili i seguenti comandi:"));
  console.log("");
  //console.log("  install -->  Installa il pacchetto specificato");
  //console.log(chalk.hex('#696969')("               parametro " + chalk.hex('#edf1d5')("<applicazione>") + " || obbligatorio"));
  //console.log("");
  //console.log("   search -->  Trova e mostra le informazioni di base dei pacchetti");
  //console.log(chalk.hex('#696969')("               parametro " + chalk.hex('#edf1d5')("<applicazione>") + " || facoltativo"));
  //console.log("");
  //console.log("     show -->  Trova e mostra le informazioni relative ad un manifest");
  //console.log(chalk.hex('#696969')("               parametro " + chalk.hex('#edf1d5')("<applicazione>") + " || obbligatorio"));
  //console.log("");
  console.log("     hash -->  Helper per eseguire l'hashing MD5 di un file");
  console.log(chalk.hex('#696969')("               parametro " + chalk.hex('#edf1d5')("<percorsofile>") + " || obbligatorio"));
  console.log("");
  console.log("     info -->  Visualizza le informazioni generali su nxget");
  console.log("");
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = commandlist;
// </edit
