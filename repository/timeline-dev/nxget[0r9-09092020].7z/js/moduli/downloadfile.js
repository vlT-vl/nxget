// downloadfile.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// Modulo che consente di effettuare il download di un file da js
// es. di utilizzo:  "downloadfile(url, out)"
//******************************************************************************

// <editor-fold> Variabili e Costanti del modulo
const https = require('https');
const fs = require('fs');
// </editor-fold>

// <editor-fold> Funzione MAIN del modulo
function downloadfile(url, out) {
  var file = fs.createWriteStream(out);
  var request = https.get(url, function(response) {
    response.pipe(file);
    file.on('finish', function() {
      file.close();
    });
  }).on('error', function(err) { // Handle errors
    fs.unlink(out);
    console.error(err);
  });
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  downloadfile
};
// </editor-fold
