// shell.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// modulo che consente l'esecuzione di comandi sulla shell dei comandi predefinita
// es. di utilizzo:  "shell(`powershell -Command "$env:COMPUTERNAME"`)"
//
// Per salvare output in una variabile:
// es. di utilizzo: "var result = shell(powershell -Command "$env:COMPUTERNAME)"
//******************************************************************************

// <editor-fold> Funzione MAIN del modulo
// funzione per l'esecuzione di comandi shell da JS
async function shell(comando) {
  const execSync = require('child_process').execSync;
  const stdout = await execSync(comando);
  var output = `${stdout}`
  await execSync.exit
  await execSync.close
  return output
}
// </editor-fold

// <editor-fold> export del modulo
module.exports = {
  shell
};
// </editor-fold
