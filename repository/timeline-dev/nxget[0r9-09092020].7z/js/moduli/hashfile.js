// hashfile.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm "md5-file"
// comando : npm install md5-file
//
// Modulo che consente di verificare md5 di un file
// es. di utilizzo:  "hashfile(filePath)"
//******************************************************************************

// <editor-fold> Variabili e Costanti del modulo
const md5File = require('md5-file')
// </editor-fold>

// <editor-fold> Funzione MAIN del modulo
function hashfile(filePath) {
 const hash = md5File.sync(filePath)
 return hash
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  hashfile
};
// </editor-fold
