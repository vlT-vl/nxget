#!/usr/bin/env node
// install.js <> code
// modulo del comando nxget "install"
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const fs = require('fs')
const yml = require('../moduli/yamlparse')
const hsh = require('../moduli/hashfile')
const dwl = require('../moduli/downloadfile')
var manifestArgv = argv._[1]
// </editor-fold>

// <editor-fold> funzione install -> installa il pacchetto selezionato
function install() {
  if (manifestArgv == undefined) {
    console.log(chalk.hex('#f63e3e')(`nxget ERROR | install`))
    console.log(chalk.hex('#f63e3e')(`Manca il parametro richiesto "<NomeApp>" -> manifest dell'applicazione da installare`))
    console.log("");
    console.log("uso: nxget install <NomeApp>");
    console.log("");
    console.log("per una lista completa dei pacchetti disponibili digita: " + chalk.hex('#fbffd2')("nxget search"));
  } else {
    searchValue(manifestArgv)
  }
}
// </editor-fold>

// <editor-fold> Funzione searchValue
//  -> Se il comando viene richiamato con parametro effetttua la ricerca
function searchValue(manifest) {
  (async function yamlData() {
    var yamlData = await yml.yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
    var ricerca = await searchEngine(yamlData, manifest)
    if (ricerca == "") {
      console.log(" ");
      console.log(chalk.hex('#b6b2b2')(`nxget || non esiste nessun pacchetto con nome: `) + chalk.hex('#f7ffc4')(manifest));
    } else {
      ricerca.forEach(function(yaml) {
        manifest = yaml.manifest
      });
      manifest = await yml.yamlparse(manifest)
      checkid(manifest)
    }
  }());
}
// </editor-fold>

// <editor-fold> Funzione checkid
//  -> effettua il check del'id o dell'idx prima di proseguire nel deploy
async function checkid(manifest) {
  switch (manifestArgv) {
    case manifest.id:
      deploy(manifest)
      break;
    case manifest.idx:
      deploy(manifest)
      break;
    default:
      console.log(chalk.hex('#f63e3e')(`nxget ERROR | install`))
      console.log(chalk.hex('#f63e3e')(`Parametro "${manifestArgv}" || id o idx non corrispondente`))
  }
}
// </editor-fold>

// <editor-fold>  Funzione deploy
//  -> Funzione per il deploy del pacchetto
async function deploy(manifest) {

  //  -> Impostazioni delle variabili del deploy
  var package = `${manifest.id}-${manifest.versione}.${manifest.installer.installertype}`
  var nxgetFLDR = `${process.env.TEMP}\\nxget`

  //  -> Log del comnado install di base
  console.log(" ");
  console.log(`Installazione del pacchetto: ` + chalk.hex('#f7ffc4')(manifest.id));
  console.log("Versione: " + chalk.hex('#f7ffc4')(manifest.versione));
  console.log(" ");
  console.log(`Download di: ` + chalk.hex('#898dee')(manifest.installer.url));

  //  -> Creazione della cartella nxget in TEMP
  if (!fs.existsSync(nxgetFLDR)) {
    await fs.mkdirSync(nxgetFLDR);
  } else {
    await fs.rmdirSync(nxgetFLDR);
    await fs.mkdirSync(nxgetFLDR);
  }

  //  -> Download del file da URL
  await dwl.downloadfile(manifest.installer.url, `${nxgetFLDR}\\${package}`)

}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  install
};
// </editor-fold>
