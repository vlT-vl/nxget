#!/usr/bin/env node
// info.js <> code
// modulo che restituisce la lista dei comandi nxget
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const packageJson = require('../../package.json');
// <editor-fold>

// <editor-fold> funzione cmdlist -> lista comandi nxget
function info() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`versione: ${packageJson.version}`))
  console.log(chalk.hex('#aba9a9')(`build: ${packageJson.build}`))
  console.log("");
  console.log("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati.")
  console.log("");
  console.log(chalk.hex('#959595')("Descrizione:"));
  console.log("nxget è un package manager che consente di installare le applicazioni e altri pacchetti dalla riga di comando");
  console.log("si basa su manifesti delle applicazioni in formato YAML per il recupero delle informazioni di installazione");
  console.log("dei software.");
  console.log("");
  console.log(chalk.hex('#959595')("Crediti"));
  console.log("Un ringraziamento speciale va a KEIVAN BEIGI, l'autore originale di AppGet, il software che ha ispirato l'idea di nxget.");
  console.log("per altre info: " + chalk.hex('#7fa2e7')("https://keivan.io/"));
  console.log("e alla community di npm e agli autori dei pacchetti npm:");
  console.log(chalk.hex('#fffede')("chalk@4.1.0"));
  console.log(chalk.hex('#fffede')("md5-file@5.0.0"));
  console.log(chalk.hex('#fffede')("yargs@15.4.1"));
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  info
};
// </editor-fold>
