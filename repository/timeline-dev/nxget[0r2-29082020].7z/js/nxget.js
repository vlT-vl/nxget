#!/usr/bin/env node
// nxget.js <> code
//******************************************************************************

// <editor-fold> import dei moduli js
const cli = require('./cli/cli')
// </editor-fold>

// <editor-fold> Variabili e Costanti di Sistema
var packageJson = require('../package.json');
var argv = require('yargs').argv
var nxgCommand = argv._[0]
var nxgParam1 = argv._[1]
var nxgParam2 = argv._[2]
var nxgParam3 = argv._[3]
var nxgParam4 = argv._[4]
// </editor-fold>

// <editor-fold> nxget cli base output
function nxgetOut() {
  console.log(" ")
  console.log("nxget | package manager")
  console.log(`ver: ${packageJson.version} build: ${packageJson.build}`)
  console.log("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati.")
  cli.cli()
}
// </editor-fold>

// <editor-fold> nxget Command Interpreter
switch (nxgCommand) {
  default:
    nxgetOut();
}
// </editor-fold>
