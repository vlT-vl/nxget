// shell.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// modulo che consente l'esecuzione di comandi sulla shell dei comandi predefinita
// es. di utilizzo:  "shell(powershell -Command "$env:COMPUTERNAME)"
//******************************************************************************

// <editor-fold> Funzione MAIN del modulo
// funzione per l'esecuzione di comandi shell da JS
function shell(comando) {
  const execSync = require('child_process').execSync;
  const stdout = execSync(comando);
  console.log(`${stdout}`);
  execSync.exit
  execSync.close
}
// </editor-fold

// <editor-fold> export del modulo
module.exports = {
  shell
};
// </editor-fold
