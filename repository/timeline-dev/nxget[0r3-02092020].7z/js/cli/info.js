#!/usr/bin/env node
// info.js <> code
// modulo che restituisce la lista dei comandi nxget
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const packageJson = require('../../package.json');
var cliTable = require('cli-table');
var npmTable;
// <editor-fold>

// <editor-fold> funzione info -> restituisce le info su nxget
function info() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`versione: ${packageJson.version}`))
  console.log(chalk.hex('#aba9a9')(`build: ${packageJson.build}`))
  console.log("");
  console.log("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati.")
  console.log("");
  console.log(chalk.hex('#959595')("Descrizione:"));
  console.log("nxget è un package manager che consente di installare le applicazioni e altri pacchetti dalla riga di comando.");
  console.log("Si basa su manifesti, file in formato YAML che contengono le informazioni necessarie per l'installazione");
  console.log("dei software.");
  console.log("");
  console.log(chalk.hex('#959595')("Crediti"));
  console.log("Un ringraziamento speciale va a KEIVAN BEIGI, l'autore originale di AppGet, il software che ha ispirato l'idea di nxget.");
  console.log("per altre info: " + chalk.hex('#7fa2e7')("https://keivan.io/"));
  console.log("e alla community di npm e agli autori dei pacchetti npm:");
  npmTab()
  console.log("");
  console.log(npmTable.toString());
}
// </editor-fold>

// <editor-fold> Costruttore Tabella npm
function npmTab() {
  npmTable = new cliTable({
    head: [chalk.hex('#959595')('pacchetto npm'), chalk.hex('#959595')('versione')],
  });
  npmTable.push(
    ["chalk", "4.1.0"],
    ["cli-table", "0.3.1"],
    ["md5-file", "5.0.0"],
    ["yargs", "15.4.1"],
  )
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  info
};
// </editor-fold>
