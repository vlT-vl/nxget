#!/usr/bin/env node
// install.js <> code
// modulo del comando nxget "install"
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const yml = require('../moduli/yamlparse')
const cmd = require('../moduli/shell')
var manifest = argv._[1]
// </editor-fold>

// <editor-fold> funzione install -> installa il pacchetto selezionato
function install() {
  if (manifest == undefined) {
    console.log(chalk.hex('#f63e3e')(`nxget ERROR | install`))
    console.log(chalk.hex('#f63e3e')(`Manca il parametro richiesto "<NomeApp>" -> manifest dell'applicazione da installare`))
    console.log("");
    console.log("uso: nxget install <NomeApp>");
    console.log("");
    console.log("per una lista completa dei pacchetti disponibili digita: " + chalk.hex('#fbffd2')("nxget search"));
  } else {
    searchValue(manifest)
  }
}
// </editor-fold>

// <editor-fold> Se il comando viene richiamato con parametro effetttua la ricerca
function searchValue(manifest) {
  (async function yamlData() {
    var yamlData = await yml.yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
    var ricerca = await searchEngine(yamlData, manifest)
    if (ricerca == "") {
      console.log(" ");
      console.log(chalk.hex('#b6b2b2')(`nxget || non esiste nessun pacchetto con nome: `) + chalk.hex('#f7ffc4')(manifest));
    } else {
      ricerca.forEach(function(yaml) {
        manifest = yaml.manifest
      });
      manifest = await yml.yamlparse(manifest)
      deploy(manifest)
    }
  }());
}
// </editor-fold>

// <editor-fold> Funzione per il deploy del pacchetto
function deploy(manifest) {
 console.log(chalk.hex('#fbffd2')("id: ") + manifest.id);
 console.log(chalk.hex('#fbffd2')("idx: ") + manifest.idx);
 console.log(chalk.hex('#fbffd2')("versione: ") + manifest.versione);
 console.log(chalk.hex('#fbffd2')("arch: ") + manifest.installer.arch)
 console.log(chalk.hex('#fbffd2')("url: ") + manifest.installer.url)
 console.log(chalk.hex('#fbffd2')("installertype: ") + manifest.installer.installertype)
 console.log(chalk.hex('#fbffd2')("arguments: ") + manifest.installer.arguments)
 console.log(chalk.hex('#fbffd2')("MD5: ") + manifest.installer.MD5)
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  install
};
// </editor-fold>
