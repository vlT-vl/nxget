// yamlparse.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm "js-yaml" e "node-fetch"
// comando : npm install js-yaml node-fetch
//
// Modulo che consente il parse di un file yaml da url https
// es. di utilizzo:
//  (async function yamlData() {
//  var yamlData = await yamlparse("filePath")
//  console.log(yamlData);
//  }());
//******************************************************************************

// <editor-fold> Variabili e Costanti del modulo
const fetch = require('node-fetch')
const yaml = require('js-yaml');
// </editor-fold>

// <editor-fold> Funzione MAIN del modulo
 async function yamlparse(filePath) {
 const yamlfetch = await fetch(filePath)
 const yamlfile = await yamlfetch.text()
 const yamlData = yaml.safeLoad(yamlfile);
 return yamlData
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  yamlparse
};
// </editor-fold
