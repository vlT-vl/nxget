#!/usr/bin/env node
// hash.js <> code
// modulo del comando nxget "hash"
//******************************************************************************

// <editor-fold> import del modulo
const hsh = require('../moduli/hashfile')
const fs = require('fs')
const argv = require('yargs').argv;
const chalk = require('chalk');
var filePath = argv._[1]
// <editor-fold>

// <editor-fold> funzione hash -> verifica file md5
function hash() {
  if (filePath != undefined) {
    if (fs.existsSync(filePath)) {
      var fileName = filePath.split("\\");
      var index = fileName.length - 1
      var md5 = hsh.hashfile(filePath)
      md5 = md5.toUpperCase()
      console.log(chalk.hex('#6ac26d')(`File: ${fileName[index]} - check md5`));
      console.log(chalk.hex('#c4fcc6')(`MD5: ${md5}`));
    }
    else {
      console.log(chalk.hex('#f63e3e')(`nxget ERROR | hash`))
      console.log(chalk.hex('#f63e3e')(`File non esistente: ${filePath}`))
    }
  } else {
    console.log(chalk.hex('#f63e3e')(`nxget ERROR | hash`))
    console.log(chalk.hex('#f63e3e')(`Manca il parametro richiesto "<PercorsoFile>" -> percorso del file di cui verificare l'hash`))
    console.log("");
    console.log("uso: nxget hash <PercorsoFile>");
  }
}
// <editor-fold>

// <editor-fold> export del modulo
module.exports = {
  hash
};
// <editor-fold>
