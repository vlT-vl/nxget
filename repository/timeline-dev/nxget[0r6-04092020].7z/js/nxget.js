#!/usr/bin/env node
// nxget.js <> code
//******************************************************************************

// <editor-fold> import dei comandi cli
const cli = {};
cli.cmdlist = require('./cli/cmdlist')
cli.hash = require('./cli/hash')
cli.info = require('./cli/info')
cli.npminfo = require('./cli/npminfo')
cli.search = require('./cli/search')
cli.show = require('./cli/show')
// </editor-fold>

// <editor-fold> Variabili e Costanti di Sistema
const packageJson = require('../package.json');
const argv = require('yargs').argv;
const chalk = require('chalk');
var nxgCommand = argv._[0]
// </editor-fold>

// <editor-fold> nxget cli base output
function nxgetOut() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`ver: ${packageJson.version} build: ${packageJson.build}`))
  console.log(chalk.hex('#aba9a9')("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati."))
  cli.cmdlist.cmdlist()
}
// </editor-fold>

// <editor-fold> nxget Command Interpreter
switch (nxgCommand) {
  case undefined:
    nxgetOut()
    break;
  case "hash":
    cli.hash.hash()
    break;
  case "info":
    cli.info.info()
    break;
  case "npminfo":
    cli.npminfo.npminfo()
    break;
  case "search":
    cli.search.search()
    break;
  case "show":
    cli.show.show()
    break;
  default:
    console.log(chalk.hex('#f63e3e')(`nxget ERROR | comando "${nxgCommand}" non riconosciuto.`))
    cli.cmdlist.cmdlist()
}
// </editor-fold>
