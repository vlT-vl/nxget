#!/usr/bin/env node
// search.js <> code
// modulo del comando nxget "search"
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const cliTable = require('cli-table');
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const yml = require('../moduli/yamlparse')
var parametroRicerca = argv._[1]
var pkgTable;
// </editor-fold>

// <editor-fold> funzione search -> cerca i pacchetti nel db di nxget
function search() {
  if (parametroRicerca == undefined) {
    searchAll()
  } else {
    searchValue()
  }
}
// </editor-fold>

// <editor-fold> Funzione Search richiamata in base al parametro

//Se il comando search viene richiamato senza parametri mostra tutti i pacchetti
function searchAll() {
  console.log(" ");
  console.log(chalk.hex('#b6b2b2')(`nxget || lista completa dei pacchetti disponibili`));
  console.log("-------------------------------------------------");
  (async function yamlData() {
    var yamlData = await yml.yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
    pkgTab(yamlData)
    console.log(pkgTable)
  }());
}

// Se il comando viene richiamato con parametro effetttua la ricerca
function searchValue() {
  (async function yamlData() {
    var yamlData = await yml.yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
    var ricerca = searchEngine(yamlData, parametroRicerca)
    if (ricerca == "") {
      console.log(" ");
      console.log(chalk.hex('#b6b2b2')(`nxget || nessun risultato della ricerca per: `) + chalk.hex('#f7ffc4')(parametroRicerca));
    } else {
      console.log(" ");
      console.log(chalk.hex('#b6b2b2')(`nxget || risultato della ricerca per: `) + chalk.hex('#f7ffc4')(parametroRicerca));
      console.log("-------------------------------------------------");
      pkgTab(ricerca)
      console.log(pkgTable)
    }
  }());
}
// </editor-fold>

// <editor-fold> Costruttore Tabella pkgTable
function pkgTab(data) {
  pkgTable = new cliTable({
    head: [chalk.hex('#959595')('Software'), chalk.hex('#959595')('id'), chalk.hex('#959595')('idx'), chalk.hex('#959595')('versione'), chalk.hex('#959595')('repository')],
  });
  data.forEach(function(yaml) {
    pkgTable.push([yaml.nome, yaml.id, yaml.pkgidx, yaml.versione, yaml.repository], )
  });
  pkgTable = pkgTable.toString()
};
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  search
};
// </editor-fold>
