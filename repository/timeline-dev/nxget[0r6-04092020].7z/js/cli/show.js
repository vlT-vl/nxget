#!/usr/bin/env node
// show.js <> code
// modulo del comando nxget "show"
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const fetch = require('node-fetch')
const searchEngine = require('search-engine');
const argv = require('yargs').argv;
const yml = require('../moduli/yamlparse')
var manifest = argv._[1]
// </editor-fold>

// <editor-fold> funzione show -> mostra le informazioni relative ad un manifest
function show() {
  if (manifest == undefined) {
    console.log(chalk.hex('#f63e3e')(`nxget ERROR | show`))
    console.log(chalk.hex('#f63e3e')(`Manca il parametro richiesto "<NomeApp>" -> manifest di cui mostrare i dettagli`))
    console.log("");
    console.log("uso: nxget show <NomeApp>");
  } else {
    searchValue(manifest)
  }
}
// </editor-fold>

// <editor-fold> Se il comando viene richiamato con parametro effetttua la ricerca
function searchValue(manifest) {
  (async function yamlData() {
    var yamlData = await yml.yamlparse("https://raw.githubusercontent.com/vlT-vl/nxget/master/manifest/package.yaml")
    var ricerca = await searchEngine(yamlData, manifest)
    if (ricerca == "") {
      console.log(" ");
      console.log(chalk.hex('#b6b2b2')(`nxget || non esiste nessun pacchetto con nome: `) + chalk.hex('#f7ffc4')(manifest));
    } else {
      console.log(" ");
      console.log(chalk.hex('#b6b2b2')(`nxget || dettagli del pacchetto: `) + chalk.hex('#f7ffc4')(manifest));
      console.log("-------------------------------------------------");
      console.log(" ");
      ricerca.forEach(function(yaml) {
        manifest = yaml.manifest
      });
      const yamlfetch = await fetch(manifest)
      const yamlfile = await yamlfetch.text()
      console.log(yamlfile);
    }
  }());
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  show
};
// </editor-fold>
