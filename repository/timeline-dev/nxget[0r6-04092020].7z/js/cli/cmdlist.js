#!/usr/bin/env node
// cmdlist.js <> code
// modulo che restituisce la lista dei comandi nxget
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
// </editor-fold>

// <editor-fold> funzione cmdlist -> lista comandi nxget
function cmdlist() {
  console.log("");
  console.log("uso: nxget <comando> <parametro>");
  console.log("");
  console.log(chalk.hex('#959595')("Sono disponibili i seguenti comandi:"));
  console.log("   search -->  Trova e mostra le informazioni di base dei pacchetti");
  console.log(chalk.hex('#aba9a9')("               parametro <NomeApp> || facoltativo"));
  console.log("     show -->  Trova e mostra le informazioni relative ad un manifest");
  console.log(chalk.hex('#aba9a9')("               parametro <NomeApp> || obbligatorio"));
  console.log("     hash -->  Helper per eseguire l'hashing di un file");
  console.log(chalk.hex('#aba9a9')("               parametro <PercorsoFile> || obbligatorio"));
  console.log("     info -->  Visualizza le informazioni generali su nxget");
  console.log("");
  console.log(chalk.hex('#959595')("Sono disponibili le seguenti opzioni:"));
  console.log("     --version -->  mostra la versione di nxget");
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  cmdlist
};
// </editor-fold>
