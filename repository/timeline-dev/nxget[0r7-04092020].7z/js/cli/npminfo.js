#!/usr/bin/env node
// npminfo.js <> code
// modulo del comando nxget "npminfo"
//******************************************************************************

// <editor-fold> import del modulo
const chalk = require('chalk');
const cliTable = require('cli-table');
const packageJson = require('../../package.json');
var npmPackages = packageJson.dependencies;
var npmTable;
// </editor-fold>

// <editor-fold> funzione info -> restituisce le info sui pacchetti npm che fanno parte di nxget
function npminfo() {
  console.log(" ");
  console.log(chalk.whiteBright("nxget | pacchetti npm"))
  console.log(chalk.hex('#959595')("pacchetti npm implementati in nxget"));
  console.log("-----------------------------------");;
  npmTab()
  console.log(npmTable);
}
// </editor-fold>

// <editor-fold> Costruttore Tabella npm
function npmTab() {
  npmTable = new cliTable({
    head: [chalk.hex('#959595')('pacchetto npm'), chalk.hex('#959595')('versione')],
  });
  var npm = Object.keys(npmPackages).map(function(key) {
    return [String(key), npmPackages[key], ];
  });
  npm.forEach(function(npm) {
    npmTable.push([npm[0], npm[1]])
  });
  npmTable = npmTable.toString()
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  npminfo
};
// </editor-fold>
