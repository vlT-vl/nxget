#!/usr/bin/env node
// cli.js <> code
// modulo che restituisce la lista dei comandi nxget
//******************************************************************************

// funzione cli -> lista comandi nxget
function cli() {
  console.log("");
  console.log("uso: nxget <comando> <opzioni>");
  console.log("");
  console.log("Sono disponibili i seguenti comandi:");
  console.log("     xxxx --> xxxxxxxxxxxx");
  console.log("");
  console.log("Sono disponibili le seguenti opzioni:");
  console.log("     --version -->  mostra la versione di nxget");
}

//export del modulo
module.exports = {
  cli
};
