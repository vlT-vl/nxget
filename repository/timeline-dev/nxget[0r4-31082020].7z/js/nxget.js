#!/usr/bin/env node
// nxget.js <> code
//******************************************************************************

// <editor-fold> import dei moduli js
const cmd = require('./moduli/shell')
const yml = require('./moduli/yamlparse')
const cli = require('./cli/cli')
// </editor-fold>

// <editor-fold> Variabili e Costanti di Sistema
const packageJson = require('../package.json');
const argv = require('yargs').argv;
const chalk = require('chalk');
var nxgCommand = argv._[0]
var nxgParam1 = argv._[1]
var nxgParam2 = argv._[2]
var nxgParam3 = argv._[3]
var nxgParam4 = argv._[4]
// </editor-fold>

// <editor-fold> nxget cli base output
function nxgetOut() {
  console.log(chalk.whiteBright("nxget | package manager"))
  console.log(chalk.hex('#aba9a9')(`ver: ${packageJson.version} build: ${packageJson.build}`))
  console.log(chalk.hex('#aba9a9')("Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo. Tutti i diritti sono riservati."))
  cli.cli()
}
// </editor-fold>

// <editor-fold> nxget Command Interpreter
switch (nxgCommand) {
  case undefined:
    nxgetOut()
    break;
  default:
    console.log(chalk.hex('#f12525')(`nxget ERROR | comando "${nxgCommand}" non riconosciuto.`))
    cli.cli()
}
// </editor-fold>
