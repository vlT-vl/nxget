// yamlparse.js <> Code
// Javascript Expansion Module
// Copyright © 2020 vlT - vl.TECH di Veronesi Lorenzo
//******************************************************************************
// NB !!:
// il modulo richiede l'installazione del pacchetto npm "js-yaml"
// comando : npm install js-yaml
//
// Modulo che consente il parsing di un file yaml da https
// es. di utilizzo:  "yamlparse(filePath)"
//
// per l'associazione dell'output del file ad una variabile
// es.     setTimeout(function () {
//           datiYaml = getYamlData()
//           console.log(datiYaml);
//         }, 70);
//******************************************************************************

// <editor-fold> Variabili e Costanti del modulo
const yaml = require('js-yaml');
const https = require('https')
const fs = require('fs');
var fileYaml;
var yamlData;
var outfile;
// </editor-fold>

// <editor-fold> Funzione MAIN del modulo
function yamlparse(filePath) {
    getYaml(filePath)
    setTimeout(function () {
      fileYaml = fs.readFileSync(outfile, 'utf8')
      yamlData = yaml.safeLoad(fileYaml);
      console.log(yamlData)
      fs.unlinkSync(outfile)
    }, 50);
}
// </editor-fold>

// <editor-fold> Funzione getYaml per il recupero del file
function getYaml(filePath) {
  outfile = `${process.env.temp}/file.yaml`
  fileYaml = fs.createWriteStream(outfile);
  https.get(filePath, response => {
    response.pipe(fileYaml)
  })
}
// </editor-fold>

// <editor-fold> Funzione getYamlData -> restituisce i dati del file
function getYamlData() {
return yamlData
}
// </editor-fold>

// <editor-fold> export del modulo
module.exports = {
  yamlparse,
  getYamlData
};
// </editor-fold
